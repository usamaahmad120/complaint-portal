How to run the Complaint Management System (poratl) Project

1. Download the zip file

2. Extract the file and copy cms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/university%20complaint%20portal/university%20complaint%20portal/portal/admin/index.php)

5. Create a database with name portal

6. Import portal.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/cms (frontend)

8. For admin panel http://localhost/university%20complaint%20portal/university%20complaint%20portal/portal/admin/index.php (admin panel)

Credential for admin panel : 
Username: admin, Password: abc123456

Credential for user panel : 
Username: usama13@gmail.com ,Password: 123456