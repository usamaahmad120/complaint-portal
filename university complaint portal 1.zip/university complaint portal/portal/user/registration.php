<?php
include('include/config.php');
error_reporting(0);
if(isset($_POST['submit']))
{
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $contactno = $_POST['contactno'];
    $status = 1;

    // Validate contact number to ensure it's exactly 11 digits
    if(preg_match('/^\d{11}$/', $contactno)) {
        $query = mysqli_query($con, "INSERT INTO users(fullName, userEmail, password, contactNo, status) VALUES ('$fullname', '$email', '$password', '$contactno', '$status')");
        
        if($query) {
            echo "<script>alert('Registration successful. Now You can login');</script>";
        } else {
            echo "<script>alert('Registration failed. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('Contact number should be exactly 11 digits.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal | User Registrations</title>
    <link rel="stylesheet" href="../admin/assets/css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    function userAvailability() {
        $("#loaderIcon").show();
        jQuery.ajax({
            url: "check_availability.php",
            data: 'email=' + $("#email").val(),
            type: "POST",
            success: function(data) {
                $("#user-availability-status1").html(data);
                $("#loaderIcon").hide();
            },
            error: function() {}
        });
    }

    function validateName() {
        var namePattern = /^[A-Za-z\s]+$/;
        var fullname = document.getElementById("fullname").value;
        if (!namePattern.test(fullname)) {
            document.getElementById("nameError").innerText = "Full Name should only contain alphabets.";
            return false;
        } else {
            document.getElementById("nameError").innerText = "";
            return true;
        }
    }

    function validateContact() {
        var contactPattern = /^\d{11}$/;
        var contactno = document.getElementById("contactno").value;
        if (!contactPattern.test(contactno)) {
            document.getElementById("contactError").innerText = "Contact number should be exactly 11 digits.";
            return false;
        } else {
            document.getElementById("contactError").innerText = "";
            return true;
        }
    }

    function validateForm() {
        return validateName() && validateContact();
    }
    </script>
</head>
<body>
    <div class="auth-wrapper">
        <div class="auth-content text-center">
            <h4>Complaint Portal<hr /><span style="color:#fff;"> User Registration</span></h4>
            <hr />
            <div class="card borderless">
                <div class="row align-items-center ">
                    <div class="col-md-12">
                        <form name="registrationForm" method="post" onsubmit="return validateForm()">
                            <div class="card-body">
                                <div class="form-group mb-3">
                                    <input type="text" class="form-control" placeholder="Full Name" id="fullname" name="fullname" required="required" autofocus oninput="validateName()">
                                    <span id="nameError" style="color:red; font-size:12px;"></span>
                                </div>
                                <div class="form-group mb-4">
                                    <input type="email" class="form-control" placeholder="Email ID" id="email" onBlur="userAvailability()" name="email" required="required">
                                    <span id="user-availability-status1" style="font-size:12px;"></span>
                                </div>
                                <div class="form-group mb-3">
                                    <input type="text" class="form-control" maxlength="11" id="contactno" name="contactno" placeholder="Contact no (11 digits)" required="required" autofocus oninput="validateContact()">
                                    <span id="contactError" style="color:red; font-size:12px;"></span>
                                </div>
                                <div class="form-group mb-3">
                                    <input type="password" class="form-control" placeholder="Password" required="required" name="password"><br>
                                </div>
                                <button class="btn btn-block btn-primary mb-4" type="submit" name="submit">Register</button>
                                <hr>
                            </div>
                        </form>
                        <i class="fa fa-home" aria-hidden="true"><a class="" href="../index.php">Back Home</a></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
			<!-- [ auth-signin ] end -->

<!-- Required Js -->
<script src="../admin/assets/js/vendor-all.min.js"></script>
<script src="../admin/assets/js/plugins/bootstrap.min.js"></script>
</body>
</html>

