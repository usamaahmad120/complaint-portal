	<div class="footer">
		<div class="container">
			 

			<b class="copyright">Design & Developed By @Usama & @Murad</b>
		</div>
	</div>